require("data")
local latches = require("latches")
local surface = require("gears.surface")
local cairo = require("lgi").cairo

local function run_once(prg,arg_string,pname,screen)
    if not prg then
        do return nil end
    end

    if not pname then
       pname = prg
    end

    if not arg_string then 
        awful.util.spawn_with_shell("pgrep -f -u jay -x '" .. pname .. "' || (" .. prg .. ")",screen)
    else
        awful.util.spawn_with_shell("pgrep -f -u jay -x '" .. pname .. " ".. arg_string .."' || (" .. prg .. " " .. arg_string .. ")",screen)
    end
end



local function grab_focus(idx)
    if idx == nil then idx = -1 end
    awful.client.focus.byidx(idx)
    if client.focus.class == "Conky" then
        awful.client.focus.byidx(idx)
    end
    client.focus:raise()
    client.focus:raise()
end

local function cycleClockwise (screen)
    screen = screen or awful.client.focus.screen
    awful.client.cycle(true, screen)
    awful.client.focus.byidx(-1)
    if client.focus.class == "Conky" then
        awful.client.cycle(true, screen)
        awful.client.focus.byidx(-1)
    end
    client.focus:raise()
end

local function cycleCounterClockwise (screen)
    screen = screen or awful.client.focus.screen
    awful.client.cycle(false, screen)
    awful.client.focus.byidx(1)
    if client.focus.class == "Conky" then
        awful.client.cycle(false, screen)
        awful.client.focus.byidx(1)
    end
    client.focus:raise()
end

local function nextTagGrp ()
    for t = 1, #tags[tags.grp] do
        awful.tag.setproperty(tags[tags.grp][t], "hide", true)
    end
    tags.grp = tags.grp + 1
    if tags.grp > 3 then tags.grp = 1 end
    for t = 1, #tags[tags.grp] do
        awful.tag.setproperty(tags[tags.grp][t], "hide", false)
    end
end

local function prevTagGrp ()
    for t = 1, #tags[tags.grp] do
        awful.tag.setproperty(tags[tags.grp][t], "hide", true)
    end
    tags.grp = tags.grp - 1
    if tags.grp < 1 then tags.grp = 3 end
    for t = 1, #tags[tags.grp] do
        awful.tag.setproperty(tags[tags.grp][t], "hide", false)
    end
end


local function keyspawn (cmd)
    return function () awful.util.spawn_with_shell(cmd) end
end

local function subList (list, first, last)
    local new = {}
    for i = first, last do
        table.insert(new, list[i])
    end
    return new
end

local function tprint (tbl, indent)
    if not indent then indent = 0 end
    if #tbl == 0 and indent == 0 then print(tostring(tbl)) end
    for k, v in pairs(tbl) do
        formatting = string.rep(" ", indent) .. tostring(k) .. ": "
        if type(v) == "table" then
            print(formatting .. tostring(v))
            if k == "parent" then return end
            if v == tbl then print(formatting .. " LOOP!!!") return end
            tprint(v, indent+1)
        elseif type(v) == 'boolean' then
            print(formatting .. tostring(v))	
        else
            print(formatting .. tostring(v))
        end
    end
end

local function getIndex (list, o)
    for i=1, #list do
        if list[i] == o then return i end
    end
    return 0
end

local function tableEqual (a, b)
    if #a ~= #b then return false end
    local flag = false
    for i = 1, #a do
        for j = 1, #b do
            if a[i] == b[j] then
                flag = true
            end
        end
        if flag then
            flag = false
        else
            return false
        end
    end
    return true
end

local function fillRed (drawable, r, g ,b)
    local r = r or 1
    local g = g or 0
    local b = b or 0
    local surf = surface(drawable.surface)
    cr = cairo.Context(surf)
    cr:save()
    cr:set_source_rgb(r, g, b)
    cr:paint()
    cr:restore()
    drawable:refresh()
end

local function key (mods, key, press, release)
    local nKey = awful.key(mods, key, press, release)
    if key:sub(1,1) == "#" then key = tostring(tonumber(key:sub(2))-9) end
    local nnKey = {mods, key, press, latches.continue}
--    print("Adding " .. tostring(nnKey) .. "  " .. nnKey[2])
--    pcall(function () utils.tprint(nnKey) end)
--    print("To globals")
--    table.insert(globalBinds, {nnkey})
--    pcall(function () utils.tprint(globalBinds) end)
    latches.addGlobalLatch(nnKey)
    return nKey
end

-- Compatibility: Lua-5.1
local function strSplit(str, pat)
   local t = {}  -- NOTE: use {n = 0} in Lua-5.0
   local fpat = "(.-)" .. pat
   local last_end = 1
   local s, e, cap = str:find(fpat, 1)
   while s do
      if s ~= 1 or cap ~= "" then
	 table.insert(t,cap)
      end
      last_end = e+1
      s, e, cap = str:find(fpat, last_end)
   end
   if last_end <= #str then
      cap = str:sub(last_end)
      table.insert(t, cap)
   end
   return t
end

local function printLatch (name)
    tprint(latches.latches[name])
end

return {run_once=run_once, grab_focus=grab_focus, nextTagGrp=nextTagGrp, prevTagGrp=prevTagGrp, keyspawn=keyspawn, subList=subList, tprint=tprint, getIndex=getIndex, tableEqual=tableEqual, fillRed=fillRed, key=key, cycleClockwise=cycleClockwise, cycleCounterClockwise=cycleCounterClockwise, strSplit=strSplit, printLatch=printLatch, latches=latches}
