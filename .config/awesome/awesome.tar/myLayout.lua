local latches = require("latches")
local tag = awful.tag
local layout = {}

tagData = {} -- will be populated by tags.lua before use
clientData = {test="test"}


local function clientNum (tab, c)
--    naughty.notify({title="Summing", text=tab, timeout=0})
    local c = c or 0
    if #tab == 0 then
--        naughty.notify({text="Empty", timeout=0})
        c = c + 1
    else
--        utils.tprint(tab)
        for k, v in pairs(tab) do
--            naughty.notify({title=k, text=v, timeout=0})
        end
        for i = 1, tab[2] do
            c = clientNum(tab[4][i], c)
        end
    end
--    naughty.notify({text=c, timeout=0})
    return c
end
local function set (p, section)
--    print("Arranging:")
--    utils.tprint(section)
--    utils.tprint(p)
    local t = tag.selected(p.screen)
    local area = p.workarea
    section.area = area
    if #section == 0 then
        for k, c in pairs(p.clients) do
            local g = {
              x = math.floor(area.x),
              y = math.floor(area.y),
              width = math.floor(area.width - c.border_width * 2),
              height = math.floor(area.height - c.border_width * 2)
            }
--            print(g.x)
--            print(g.y)
--            print(g.width)
--            print(g.height)
            c:geometry(g)
            clientData[c] = section
        end
    else
--        naughty.notify({text=clientsNum, replaces_id=naughtyIDs.clientsNum})
        local nP = {}
        nP.clients = {}
        nP.workarea = {}
        nP.workarea.width = area.width
        nP.workarea.height = area.height
        nP.workarea.x = area.x
        nP.workarea.y = area.y
        for i = 1, section[2] do
            local wClientsNum = clientNum(section[4][i])
            if section[4][i].parent == nil then section[4][i].parent = section end
--            print(wClientsNum .. " " .. #p.clients)
            nP.clients = {}
            if wClientsNum <= #p.clients then
--                print("TMC " .. wClientsNum .. " " .. #p.clients)
                for j = 1, wClientsNum do
                    table.insert(nP.clients, p.clients[1])
                    table.remove(p.clients, 1)
                end
                if section[1] == "h" then
--                    print("h area")
                    nP.workarea.x = area.x + area.width * (section[3][i-1] or 0)
--                    print("new x: " .. nP.workarea.x)
                    nP.workarea.width = (area.width * (section[3][i] or 1)) - area.width * (section[3][i-1] or 0)
--                    print("new width: " .. nP.workarea.width)
                elseif section[1] == "v" then
--                    print("v area")
                    nP.workarea.y = area.y + area.height * (section[3][i-1] or 0)
--                    print("new y: " .. nP.workarea.y)
                    nP.workarea.height = (area.height * (section[3][i] or 1)) - area.height * (section[3][i-1] or 0)
--                    print("sub-height: " .. (section[3][i] or 1))
--                    print("new height: " .. nP.workarea.height)
                end
--                print("Passing: ")
--                utils.tprint(nP.clients)
--                print("To: ")
--                utils.tprint(section[4][i])
                set(nP, section[4][i])
            elseif wClientsNum > #p.clients then
--                print("NEC " .. wClientsNum .. " " .. #p.clients)
                while #p.clients > 0 do
                    table.insert(nP.clients, p.clients[1])
                    table.remove(p.clients, 1)
                end
                if section[1] == "h" then
--                    print("h area")
                    nP.workarea.x = area.x + area.width * (section[3][i-1] or 0)
--                    print("new x: " .. nP.workarea.x)
                    nP.workarea.width = (area.width * (section[3][i] or 1)) - nP.workarea.x
--                    print("new width: " .. nP.workarea.width)
                elseif section[1] == "v" then
                    nP.workarea.y = area.y + area.height * (section[3][i-1] or 0)
--                    print("new y: " .. nP.workarea.y)
                    nP.workarea.height = (area.height * (section[3][i] or 1)) - nP.workarea.y
--                    print("new width: " .. nP.workarea.width)
                end
                return set(nP, section[4][i])
            end
        end
        set(p, {})
    end
end

function layout.arrange (p)
    set(p, tagData[tag.selected(p.screen)])
end

local function divideV ()
    local section = clientData[client.focus]
    section[1] = "v"
    section[2] = 2
    section[3] = {0.5}
    section[4] = {{}, {}}
    awful.layout.arrange(client.focus.screen)
end

local function divideH ()
    local section = clientData[client.focus]
    section[1] = "h"
    section[2] = 2
    section[3] = {0.5}
    section[4] = {{}, {}}
    awful.layout.arrange(client.focus.screen)
end

local function join ()
    local section = clientData[client.focus]
    section.parent[1] = nil
    section.parent[2] = nil
    section.parent[3] = nil
    section.parent[4] = nil
    awful.layout.arrange(client.focus.screen)
end


local function divideRecurse (s, section)
    local parent = section.parent
    if parent == nil then return -1 end
    if s == "Top" then
        if parent[1] == "v" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= 1 then
                return {parent[3], idx-1}
            else
                return divideRecurse(s, parent)
            end
        else
            return divideRecurse(s, parent)
        end
    elseif s == "Bottom" then
        if parent[1] == "v" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= parent[2] then
                return {parent[3], idx}
            else
                return divideRecurse(s, parent)
            end
        else
            return divideRecurse(s, parent)
        end
    elseif s == "Left" then
        if parent[1] == "h" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= 1 then
                return {parent[3], idx-1}
            else
                return divideRecurse(s, parent)
            end
        else
            return divideRecurse(s, parent)
        end
    elseif s == "Right" then
        if parent[1] == "h" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= parent[2] then
                return {parent[3], idx}
            else
                return divideRecurse(s, parent)
            end
        else
            return divideRecurse(s, parent)
        end
    end
end

local function getDivide (c, s)
    local section = clientData[c]
    local parent = section.parent
    if parent == nil then return -1 end
    if s == "Top" then
        if parent[1] == "v" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= 1 then
                return {parent[3], idx-1}
            else
                return divideRecurse(s, section)
            end
        else
            return divideRecurse(s, section)
        end
    elseif s == "Bottom" then
        if parent[1] == "v" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= parent[2] then
                return {parent[3], idx}
            else
                return divideRecurse(s, section)
            end
        else
            return divideRecurse(s, section)
        end
    elseif s == "Left" then
        if parent[1] == "h" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= 1 then
                return {parent[3], idx-1}
            else
                return divideRecurse(s, section)
            end
        else
            return divideRecurse(s, section)
        end
    elseif s == "Right" then
        if parent[1] == "h" then
            idx = utils.getIndex(parent[4], section)
            if idx ~= parent[2] then
                return {parent[3], idx}
            else
                return divideRecurse(s, section)
            end
        else
            return divideRecurse(s, section)
        end
    end
end


local function getTopDivide ()
    clientData.divide = getDivide(client.focus, "Top")
    naughty.notify({text=clientData.divide})
    naughty.notify({text=clientData.divide[1]})
end

local function getBottomDivide ()
    clientData.divide = getDivide(client.focus, "Bottom")
    naughty.notify({text=clientData.divide})
    naughty.notify({text=clientData.divide[1]})
end

local function getLeftDivide ()
    clientData.divide = getDivide(client.focus, "Left")
    naughty.notify({text=clientData.divide})
    naughty.notify({text=clientData.divide[1]})
end

local function getRightDivide ()
    clientData.divide = getDivide(client.focus, "Right")
    naughty.notify({text=clientData.divide})
    naughty.notify({text=clientData.divide[1]})
end


local function incDivide ()
    if clientData.divide == -1 then return end
    x = clientData.divide[1][clientData.divide[2]]+.01
    if x < (clientData.divide[1][clientData.divide[2]+1] or 1) then
        clientData.divide[1][clientData.divide[2]] = x
    end
    awful.layout.arrange(client.focus.screen)
end

local function decDivide ()
    if clientData.divide == -1 then return end
    x = clientData.divide[1][clientData.divide[2]]-.01
    if x > (clientData.divide[1][clientData.divide[2]-1] or 0) then
        clientData.divide[1][clientData.divide[2]] = x
    end
    awful.layout.arrange(client.focus.screen)
end

local function resetDivide ()
    clientData.divide = -1
end

local function incDivides ()
    local section = clientData[client.focus]
    local parent = section.parent
    parent[2] = parent[2] + 1
    fraction = 1/parent[2]
    parent[4] = {}
    for i = 1, parent[2] do
        parent[4][i] = {}
    end
    for i = 1, parent[2]-1 do
        parent[3][i] = fraction + (parent[3][i-1] or 0)
    end
    awful.layout.arrange(client.focus.screen)
end

local function decDivides ()
    local section = clientData[client.focus]
    local parent = section.parent
    parent[2] = parent[2] - 1
    if parent[2] == 0 then join() end
    fraction = 1/parent[2]
    parent[3] = {}
    parent[4] = {}
    for i = 1, parent[2] do
        parent[4][i] = {}
    end
    for i = 1, parent[2]-1 do
        parent[3][i] = fraction + (parent[3][i-1] or 0)
    end
    awful.layout.arrange(client.focus.screen)
end
layout.name = "myLayout"




layout.latch = latches.latch("layout controls", {
    {n="Split", {}, "s", latches.latch("Split", {
          {n="Vertical", {}, "v", divideV, latches.exit},
          {n="Horizontal", {}, "h", divideH, latches.exit}})},
    {n="Join", {}, "j", join, latches.exit},
    {n="Top Divide", {}, "Up", getTopDivide, latches.continue, esc=resetDivide},
    {n="Top Divide", {}, "Down", getBottomDivide, latches.continue, esc=resetDivide},
    {n="Top Divide", {}, "Left", getLeftDivide, latches.continue, esc=resetDivide},
    {n="Top Divide", {}, "Right", getRightDivide, latches.continue, esc=resetDivide},
    {n="Inc Divide", {}, "=", incDivide, latches.continue},
    {n="Dec Divide", {}, "-", decDivide, latches.continue},
    {n="Inc Divides", {"Control"}, "=", incDivides, latches.continue},
    {n="Inc Divides", {"Control"}, "-", decDivides, latches.continue}})


return layout
