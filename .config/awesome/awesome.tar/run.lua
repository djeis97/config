-- Run
io.popen('bash -e "export MPD_HOST=10.42.0.90"')

-- Run once


utils.run_once("conky")
