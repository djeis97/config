require("data")
local myLayout = require("myLayout")

-- {{{ Tags
-- Define a tag table which hold all screen tags.

tags = {}
tags[1] = awful.tag({ "Admin", "Files", "Docs", "FF", "Chrome", 16, "Skype", 18, "PulseAudio" }, 1, layouts[1])
tags[2] = awful.tag({ 21, 22, 23, 24, 25, 26, 27, 28, 29 }, 1, layouts[1])
tags[3] = awful.tag({ "MPD", 32, 33, 34, 35, 36, 37, "Jack", "Alsa" }, 1, layouts[1])
tags.grp = 1


for t = 1, #tags[2] do
    awful.tag.setproperty(tags[2][t], "hide", true)
end

for t = 1, #tags[3] do
    awful.tag.setproperty(tags[3][t], "hide", true)
end

for n = 1,3 do
    for t = 1, #tags[n] do
        tagData[tags[n][t]] = {}
        awful.layout.set(myLayout, tags[n][t])
    end
end

tagData[tags[2][3]] = {"h", 2, {0.5}, {
                          {"v", 3, {0.333, 0.667}, {
                              {}, 
                              {}, 
                              {}}}, 
                          {"v", 2, {0.5}, {
                              {}, 
                              {}}}}}
-- }}}